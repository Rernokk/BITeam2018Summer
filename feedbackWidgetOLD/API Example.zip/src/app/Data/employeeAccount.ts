export class EmployeeAccount {
    a: string;
    b: string;
}
