import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-create-component',
  templateUrl: './employee-create-component.component.html',
  styleUrls: ['./employee-create-component.component.css']
})
export class EmployeeCreateComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
