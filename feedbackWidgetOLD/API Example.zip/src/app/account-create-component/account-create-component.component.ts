import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-create-component',
  templateUrl: './account-create-component.component.html',
  styleUrls: ['./account-create-component.component.css']
})
export class AccountCreateComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
