import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-list-component',
  templateUrl: './account-list-component.component.html',
  styleUrls: ['./account-list-component.component.css']
})
export class AccountListComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
