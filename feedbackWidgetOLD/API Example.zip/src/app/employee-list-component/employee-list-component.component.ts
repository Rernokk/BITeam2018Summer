import { Component, OnInit } from '@angular/core';
import { EmployeeAccount } from '../Data/employeeAccount';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-employee-list-component',
  templateUrl: './employee-list-component.component.html',
  styleUrls: ['./employee-list-component.component.css']
})
export class EmployeeListComponentComponent implements OnInit {
  temp: EmployeeAccount = {
    a: 'abc',
    b: 'ASDF'
  };
  private str: string;
  constructor(private apiService: ApiService) { }

  ngOnInit() {
     this.TryConnection();
     this.temp.a = 'a';
  }
  public TryConnection() {
      this.apiService.testConnection().subscribe((data: object) => {
          // Since we know what the return is, we can pull data as such.
          this.str = data['data'];
          console.log(data);
      });
  }
}
